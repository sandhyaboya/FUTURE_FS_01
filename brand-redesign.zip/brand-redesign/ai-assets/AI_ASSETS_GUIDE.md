
AI Asset Generation Guide
-------------------------

Suggested workflow:
1) Use Adobe Firefly to generate 3 logo variants and 3 hero images. Export SVG for logos and PNG for hero images.
2) Use Durable or other AI website builder to create layout inspiration and copy suggestions.
3) Extract color palettes from generated images (use tools like Coolors or Colormind) and add to Tailwind theme extend in tailwind.config.js.
4) Place final assets into `site/public/ai/` and reference them in components/pages.

Files to include:
- ai/logo-variant-1.svg
- ai/logo-variant-2.svg
- ai/palette.json
- ai/hero-1.png, hero-2.png
