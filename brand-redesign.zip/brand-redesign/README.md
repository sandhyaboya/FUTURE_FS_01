# Brand Redesign — Next.js + Tailwind + AI assets

This starter demonstrates a workflow for redesigning a brand website using AI tools and modern stack.
Folders:
- site/ : Next.js + Tailwind starter site (pages, styles, components)
- ai-assets/ : guidance for generating logos, palettes, hero images with AI (Adobe Firefly, Durable)
- cms-guides/ : setup guides for Strapi & Firebase as CMS/backends

## To run locally (site)
1) cd site
2) npm install
3) npm run dev
4) Open http://localhost:3000

## AI Tools suggested
- Adobe Firefly — generate logos, hero images, and design elements.
- Durable — AI-powered website builder to prototype copy/layout.
- Coolors / Paletton — extract and fine-tune palettes.

## Next steps I can do for you
- Generate Tailwind theme with the selected palette and update components.
- Build full component library: Navbar, Hero, CaseStudy, Contact form with CMS integration.
- Create Strapi content types and seed example content + a sample integration in Next.js `getStaticProps`.

Tell me which brand you'd like me to redesign (e.g., Nike, Starbucks, Spotify) and I will: generate 3 logo ideas, a color palette, and a 3-screen mockup (home, product, contact) using the AI tools you prefer.
