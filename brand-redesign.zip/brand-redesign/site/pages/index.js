export default function Home(){
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <header className="max-w-6xl mx-auto p-8 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-cyan-400 rounded-xl flex items-center justify-center text-white font-bold">BR</div>
          <div>
            <h1 className="text-2xl font-semibold">Brand Redesign — Demo</h1>
            <p className="text-sm text-slate-600">Modern UI for your favorite brand + AI-generated assets</p>
          </div>
        </div>
        <nav className="flex gap-4 text-sm text-slate-700">
          <a href="#work">Work</a>
          <a href="#branding">Branding</a>
          <a href="#cms">CMS</a>
        </nav>
      </header>

      <section id="hero" className="max-w-6xl mx-auto p-8 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-4xl font-extrabold mb-4">A modern redesign powered by AI tools</h2>
          <p className="text-slate-600 mb-6">We propose a refreshed UI/UX using Next.js + Tailwind and AI-generated branding from tools like Adobe Firefly & Durable. CMS via Strapi or Firebase for content management.</p>
          <ul className="space-y-2 text-slate-700">
            <li>• Clean, responsive layouts</li>
            <li>• SEO-first pages and structured data</li>
            <li>• AI-generated logos, palettes, and hero imagery</li>
          </ul>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-md">
          <h3 className="font-semibold mb-2">AI Branding Preview</h3>
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 border rounded">Logo A<br/><small className="text-xs">Generated</small></div>
            <div className="p-3 border rounded">Palette<br/><small className="text-xs">Generated</small></div>
            <div className="p-3 border rounded">Mockup<br/><small className="text-xs">Generated</small></div>
          </div>
        </div>
      </section>

      <section id="work" className="max-w-6xl mx-auto p-8">
        <h3 className="text-2xl font-semibold mb-4">Key screens</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 bg-white rounded-lg shadow">Homepage prototype</div>
          <div className="p-4 bg-white rounded-lg shadow">Product/Service detail</div>
          <div className="p-4 bg-white rounded-lg shadow">Checkout / Contact</div>
        </div>
      </section>

      <section id="cms" className="max-w-6xl mx-auto p-8">
        <h3 className="text-2xl font-semibold mb-4">CMS & Data</h3>
        <p className="text-slate-600 mb-4">You can choose Strapi (self-hosted, flexible content types) or Firebase (serverless, realtime) as backend. See `cms-guides` for setup steps and example content models.</p>
      </section>

      <footer className="max-w-6xl mx-auto p-8 text-sm text-slate-500">
        © {new Date().getFullYear()} Brand Redesign Demo — Next.js + Tailwind
      </footer>
    </main>
  )
}