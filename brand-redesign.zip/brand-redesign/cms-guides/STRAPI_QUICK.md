
Strapi Setup (quick)
--------------------
1) Install Strapi (recommended: v4) on your server or use Strapi Cloud.
2) Create content types: Pages (title, slug, body), Blocks, Team, CaseStudy, Asset (media).
3) Configure roles & permissions for public read for published pages.
4) Use GraphQL or REST endpoints to fetch content from Next.js (getStaticProps / getServerSideProps).
5) Connect media provider (S3) for production.

Useful endpoints:
- GET /api/pages?filters[slug][$eq]=home
- GET /api/case-studies
