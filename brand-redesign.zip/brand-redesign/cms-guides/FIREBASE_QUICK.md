
Firebase Setup (quick)
----------------------
1) Create a Firebase project and enable Firestore & Hosting.
2) Define collections: pages, caseStudies, assets, users.
3) Use Firebase Admin SDK in server-side API routes or use client SDK with proper rules.
4) Use Hosting for static export of Next.js (next export) or SSR with Vercel + Firebase for functions.

Sample Firestore doc structure:
- pages/home: { title, hero, blocks: [...] }
- caseStudies/{id}: { title, description, images: [...] }
