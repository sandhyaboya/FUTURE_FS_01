
const { useState, useEffect } = React;

const API_URL = "http://localhost:5000/api";

const Hero = () => (
  <section className="hero container">
    <span className="kicker">Java Full‑Stack Developer</span>
    <h1>Boya Sandhya</h1>
    <p>
      Recent CSE graduate skilled in Java, Spring Boot, React, and MySQL. Passionate about building clean, reliable web apps and shipping value in sprints.
    </p>
    <div className="row">
      <a className="btn" href="assets/Boya.Sandhya.pdf" target="_blank" rel="noopener">Download Resume</a>
      <a className="btn" href="#contact">Contact Me</a>
      <a className="btn" href="https://github.com/sandhyaboya" target="_blank" rel="noopener">GitHub</a>
      <a className="btn" href="https://www.linkedin.com/in/boyasandhya02" target="_blank" rel="noopener">LinkedIn</a>
      <span className="badge">Available for Opportunities</span>
    </div>
  </section>
);

const SkillChip = ({label}) => <span className="tag">{label}</span>;

const Skills = () => (
  <section className="section container" id="skills">
    <h2>Skills</h2>
    <div className="card">
      <div className="tags">
        {[
          "Java","JDBC","J2EE","Servlets","JSP","Spring Boot","React","JavaScript","HTML","CSS","Bootstrap",
          "MySQL","Git","GitHub","Tomcat"
        ].map(s => <SkillChip key={s} label={s}/>)}
      </div>
    </div>
  </section>
);

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${API_URL}/projects`)
      .then(r => r.json())
      .then(data => { setProjects(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <section className="section container" id="projects">
      <h2>Projects</h2>
      {loading && <p>Loading projects…</p>}
      <div className="row">
        {projects.map(p => (
          <div className="card" key={p.id}>
            <h3>{p.title}</h3>
            <p>{p.description}</p>
            {p.link && <p><a href={p.link} target="_blank" rel="noopener">View</a></p>}
            {p.tags && <div className="tags">{p.tags.split(',').map(t => <span className="tag" key={t}>{t.trim()}</span>)}</div>}
          </div>
        ))}
      </div>
    </section>
  );
};

const ResumeSection = () => (
  <section className="section container" id="resume">
    <h2>Interactive Resume</h2>
    <div className="card">
      <table className="table">
        <thead><tr><th>Education</th><th>Details</th></tr></thead>
        <tbody>
          <tr><td>GATES Institute of Technology</td><td>B.Tech CSE (2020–2024), CGPA 8.3</td></tr>
          <tr><td>Sri Vivekananda Junior Kalasala</td><td>Intermediate MPC (2018–2020), CGPA 8.63</td></tr>
          <tr><td>Sri Vidyanikethan (E.M) H.S</td><td>SSC (2017–2018), CGPA 8.8</td></tr>
        </tbody>
      </table>
      <div style={{height:12}}/>
      <table className="table">
        <thead><tr><th>Certifications</th><th>Issuer</th></tr></thead>
        <tbody>
          <tr><td>Java Full Stack</td><td>Pentagon Space</td></tr>
          <tr><td>Java Full Stack</td><td>Consensus Academy</td></tr>
          <tr><td>Salesforce Developer Virtual Internship</td><td>Smart Internz</td></tr>
          <tr><td>HTML & CSS</td><td>SoloLearn</td></tr>
          <tr><td>Data Science</td><td>Coursera</td></tr>
        </tbody>
      </table>
    </div>
  </section>
);

const Contact = () => {
  const [form, setForm] = useState({name:"", email:"", message:""});
  const [status, setStatus] = useState(null);
  const [sending, setSending] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setSending(true);
    setStatus(null);
    try{
      const res = await fetch(`${API_URL}/contact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if(res.ok){ setStatus({ok:true, msg:data.message||"Message sent!"}); setForm({name:"",email:"",message:""}); }
      else { setStatus({ok:false, msg:data.error||"Something went wrong"}); }
    }catch(err){
      setStatus({ok:false, msg:"Network error"});
    }finally{
      setSending(false);
    }
  };

  return (
    <section className="section container" id="contact">
      <h2>Contact</h2>
      <div className="card">
        <form onSubmit={submit} className="grid" style={{gridTemplateColumns:"1fr"}}>
          <div>
            <label>Name</label>
            <input className="input" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
          </div>
          <div>
            <label>Email</label>
            <input className="input" type="email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} required />
          </div>
          <div>
            <label>Message</label>
            <textarea className="input" rows="5" value={form.message} onChange={e=>setForm({...form, message:e.target.value})} required />
          </div>
          <div className="row">
            <button className="btn" type="submit" disabled={sending}>{sending ? "Sending..." : "Send"}</button>
            {status && <span className="badge" style={{background: status.ok ? "linear-gradient(90deg,#16a34a,#22d3ee)" : "linear-gradient(90deg,#ef4444,#f59e0b)"}}>{status.msg}</span>}
          </div>
          <small className="mono">Your message will also be saved in the database.</small>
        </form>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer>
    <div className="container">
      <div className="row">
        <span>© {new Date().getFullYear()} Boya Sandhya</span>
        <span className="mono">Built with React + Node + MySQL</span>
      </div>
    </div>
  </footer>
);

const App = () => (
  <>
    <nav className="nav">
      <div className="nav-inner container">
        <div className="brand">Sandhya<span className="badge">Portfolio</span></div>
        <div className="row">
          <a href="#skills" className="btn">Skills</a>
          <a href="#projects" className="btn">Projects</a>
          <a href="#resume" className="btn">Resume</a>
          <a href="#contact" className="btn">Contact</a>
        </div>
      </div>
    </nav>
    <Hero/>
    <Skills/>
    <Projects/>
    <ResumeSection/>
    <Contact/>
    <Footer/>
  </>
);

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
