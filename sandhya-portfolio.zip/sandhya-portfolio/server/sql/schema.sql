-- Create database & tables
CREATE DATABASE IF NOT EXISTS portfolio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE portfolio;

CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  link VARCHAR(500) DEFAULT '',
  tags VARCHAR(500) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed example projects
INSERT INTO projects (title, description, link, tags) VALUES
('Online College Grievance Portal', 'Web portal for students to submit and track grievances; improves transparency and response time.', '', 'JSP,Servlets,MySQL,Java'),
('Event Management System', 'J2EE + JDBC + MySQL app with user registration and event workflows (MVC).', '', 'J2EE,JDBC,MySQL,HTML,CSS,JavaScript');
