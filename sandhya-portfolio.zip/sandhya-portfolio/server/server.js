import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import nodemailer from 'nodemailer';
import { pool } from './db.js';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Serve static client (optional for quick local preview)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use('/', express.static(path.join(__dirname, '../client')));

// Email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587', 10),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

// Health
app.get('/api/health', (req,res)=>res.json({ok:true}));

// Get projects
app.get('/api/projects', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, title, description, link, tags FROM projects ORDER BY id DESC');
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Add a project (simple demo)
app.post('/api/projects', async (req, res) => {
  const { title, description, link, tags } = req.body;
  if(!title || !description) return res.status(400).json({error:'title & description required'});
  try {
    const [result] = await pool.query('INSERT INTO projects (title, description, link, tags) VALUES (?,?,?,?)', [title, description, link || '', tags || '']);
    res.json({ id: result.insertId, message: 'Project added' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to add project' });
  }
});

// Contact form
app.post('/api/contact', async (req, res) => {
  const { name, email, message } = req.body;
  if(!name || !email || !message) return res.status(400).json({error:'All fields are required'});
  try {
    // Save to DB
    await pool.query('INSERT INTO contacts (name,email,message) VALUES (?,?,?)', [name, email, message]);

    // Send notification email
    if(process.env.SMTP_USER && process.env.SMTP_PASS){
      await transporter.sendMail({
        from: `"Portfolio Bot" <${process.env.SMTP_USER}>`,
        to: process.env.EMAIL_TO || process.env.SMTP_USER,
        subject: `New portfolio contact from ${name}`,
        text: `Name: ${name}
Email: ${email}

${message}`
      });
    }

    res.json({ message: 'Thanks! I will get back to you shortly.' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to submit contact form' });
  }
});

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
