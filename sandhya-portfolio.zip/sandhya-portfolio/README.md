# Sandhya Portfolio — React + Node + MySQL

A personal portfolio that showcases skills, projects, and achievements with:
- Interactive resume & projects (fetched from MySQL)
- Contact form with email notifications (Node + Nodemailer)
- SEO (meta tags, Open Graph, robots.txt, sitemap.xml)

## Quick Start

### 1) MySQL
1. Start MySQL locally.
2. Run the SQL to create the DB/tables and seed projects:
   ```sql
   SOURCE server/sql/schema.sql;
   ```

### 2) Server
```bash
cd server
cp .env.example .env
# Edit .env: DB creds & SMTP (use an app password for Gmail)
npm install
npm run dev
```
Server runs at **http://localhost:5000** and also serves the client.

### 3) Client
With the server running, open:
```
/client/index.html
```
You can also host client via any static server (the server already serves it).

## API
- `GET /api/projects` — list projects
- `POST /api/projects` — add a project `{title, description, link?, tags?}`
- `POST /api/contact` — save message and email `{name, email, message}`

## SEO
- `client/robots.txt` and `client/sitemap.xml` included
- Open Graph & JSON-LD in `client/index.html`

## Deploy Notes
- Serve `/client` via Netlify/Vercel and host Node on Render/Railway, or keep Node on the same VM.
- Update `og:url` and sitemap/robots with your real domain.
