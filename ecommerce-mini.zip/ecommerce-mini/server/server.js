import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Pool } from 'pg';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || `postgresql://${process.env.DB_USER}:${process.env.DB_PASSWORD}@${process.env.DB_HOST}:${process.env.DB_PORT || 5432}/${process.env.DB_NAME}`
});

// Serve client static for quick preview
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use('/', express.static(path.join(__dirname, '../client')));

// Endpoints
app.get('/api/health', (req,res)=> res.json({ok:true}));

app.get('/api/products', async (req,res)=>{
  try{
    const { rows } = await pool.query('SELECT id, title, description, price, category, image FROM products ORDER BY id');
    res.json(rows);
  }catch(e){ console.error(e); res.status(500).json({error:'failed'}) }
});

app.post('/api/checkout', async (req,res)=>{
  const { customer, items } = req.body;
  if(!customer || !items || !items.length) return res.status(400).json({error:'invalid payload'});
  try{
    const client = await pool.connect();
    try{
      await client.query('BEGIN');
      const orderRes = await client.query('INSERT INTO orders(customer_name,email,address,total) VALUES($1,$2,$3,$4) RETURNING id', [customer.name, customer.email, customer.address, items.reduce((s,i)=>s+i.price*i.qty,0)]);
      const orderId = orderRes.rows[0].id;
      const insertPromises = items.map(i => client.query('INSERT INTO order_items(order_id, product_id, title, price, qty) VALUES($1,$2,$3,$4,$5)', [orderId, i.id, i.title, i.price, i.qty]));
      await Promise.all(insertPromises);
      await client.query('COMMIT');
      res.json({message: 'Order placed (simulation). Order ID: ' + orderId});
    }catch(err){
      await client.query('ROLLBACK');
      throw err;
    }finally{ client.release(); }
  }catch(e){ console.error(e); res.status(500).json({error:'checkout failed'}); }
});

app.get('/api/orders', async (req,res)=>{
  try{
    const { rows } = await pool.query('SELECT * FROM orders ORDER BY created_at DESC LIMIT 20');
    res.json(rows);
  }catch(e){ console.error(e); res.status(500).json({error:'failed'}) }
});

const port = process.env.PORT || 5000;
app.listen(port, ()=> console.log('Server listening on', port));
