-- PostgreSQL schema for mini e-commerce
CREATE DATABASE IF NOT EXISTS ecom_demo;
-- Note: some Postgres setups don't allow CREATE DATABASE inside transaction files, run manually if needed.
-- Tables
CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  category VARCHAR(100) DEFAULT 'general',
  image VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  customer_name VARCHAR(200),
  email VARCHAR(200),
  address TEXT,
  total NUMERIC(12,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER,
  title VARCHAR(255),
  price NUMERIC(10,2),
  qty INTEGER
);

-- Seed products
INSERT INTO products (title, description, price, category, image) VALUES
('Wireless Headphones', 'Comfortable over-ear headphones with long battery life', 2999.00, 'electronics', ''),
('Coffee Mug', 'Ceramic mug — 350ml, dishwasher safe', 349.00, 'kitchen', ''),
('Bluetooth Speaker', 'Portable speaker with rich bass', 1599.00, 'electronics', '');
