# Mini E-Commerce Storefront

Stack: React (useContext), Bootstrap, Node.js (Express), PostgreSQL (optional)

Features:
- Product listing with search/filter
- Shopping cart using React useContext (persisted to localStorage)
- Quantity control & cart management
- Checkout simulation (server stores order + items)
- Simple endpoints to view products and orders

## Quick start (local)

1) PostgreSQL
- Create DB and run schema: `server/sql/schema.sql`
- Example (psql): `psql -U postgres -f server/sql/schema.sql -d ecom_demo`

2) Server
```bash
cd server
cp .env.example .env   # fill DB creds or use DATABASE_URL
npm install
npm run start
```
Server runs on http://localhost:5000 and serves the client files for quick preview.

3) Client
- Open `client/index.html` in browser, or visit http://localhost:5000/

## API
- `GET /api/products` — list products
- `POST /api/checkout` — place simulated order `{ customer:{name,email,address}, items:[{id,title,price,qty}] }`
- `GET /api/orders` — list recent orders

## Notes
- This is a demo — no payments. For production: add proper validation, auth, and payment integration.
- Want login/order history? I can add JWT auth and user tables next.
