
const { useState, useEffect, createContext, useContext } = React;

/* --------- Config --------- */
const API = "http://localhost:5000/api";

/* --------- Cart Context (useContext) --------- */
const CartContext = createContext();

function CartProvider({children}){
  const [cart, setCart] = useState(() => {
    try{ return JSON.parse(localStorage.getItem("cart")||"[]"); }catch(e){ return []; }
  });
  useEffect(()=> localStorage.setItem("cart", JSON.stringify(cart)), [cart]);

  const add = (product) => {
    setCart(prev => {
      const existing = prev.find(p=>p.id===product.id);
      if(existing) return prev.map(p=> p.id===product.id ? {...p, qty: p.qty+1} : p);
      return [...prev, {...product, qty:1}];
    });
  };
  const updateQty = (id, qty) => {
    setCart(prev => prev.map(p=> p.id===id ? {...p, qty: Math.max(1, qty)} : p));
  };
  const remove = (id) => setCart(prev => prev.filter(p=>p.id!==id));
  const clear = () => setCart([]);

  const total = cart.reduce((s,p)=> s + p.price * p.qty, 0);
  return <CartContext.Provider value={{cart, add, updateQty, remove, clear, total}}>{children}</CartContext.Provider>
}

function useCart(){ return useContext(CartContext); }

/* --------- Components --------- */
function Header(){ 
  const {cart} = useCart();
  return (
    <div className="header container">
      <h2>Demo Store</h2>
      <div>
        <a href="#cart" className="me-3">Cart <span className="badge-cart">{cart.length}</span></a>
        <a href="#products">Products</a>
      </div>
    </div>
  )
}

function ProductList(){
  const [products, setProducts] = useState([]);
  const [q, setQ] = useState("");
  const [filtered, setFiltered] = useState([]);
  const { add } = useCart();

  useEffect(()=> {
    fetch(API+"/products").then(r=>r.json()).then(setProducts).catch(()=>setProducts([]));
  },[]);

  useEffect(()=> {
    const qq = q.trim().toLowerCase();
    setFiltered(products.filter(p=> p.title.toLowerCase().includes(qq) || p.description.toLowerCase().includes(qq) || p.category.toLowerCase().includes(qq)));
  }, [q, products]);

  return (
    <section id="products" className="container mb-4">
      <div className="mb-3 d-flex gap-2">
        <input className="form-control" placeholder="Search or filter by category" value={q} onChange={e=>setQ(e.target.value)} />
      </div>
      <div className="d-flex flex-wrap gap-3">
        { (filtered.length ? filtered : products).map(p => (
          <div key={p.id} className="card product-card p-2" style={{width: '220px'}}>
            <img src={p.image||'assets/placeholder.png'} className="card-img-top card-img" alt={p.title} />
            <div className="card-body p-2">
              <h5 style={{fontSize:16}}>{p.title}</h5>
              <p style={{fontSize:13,color:'#6b7280'}}>{p.category}</p>
              <p style={{margin:0,fontWeight:700}}>₹{p.price.toFixed(2)}</p>
              <div className="mt-2 d-grid">
                <button className="btn btn-primary btn-sm" onClick={()=>add(p)}>Add to cart</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Cart(){
  const {cart, updateQty, remove, clear, total} = useCart();
  const [checkoutMsg, setCheckoutMsg] = useState(null);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({name:"", email:"", address:""});

  const checkout = async ()=>{
    if(!form.name || !form.email || !form.address){ setCheckoutMsg({ok:false,msg:"Fill all checkout fields."}); return; }
    setLoading(true);
    try{
      const res = await fetch(API+"/checkout", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({customer: form, items: cart})
      });
      const data = await res.json();
      if(res.ok){ setCheckoutMsg({ok:true,msg:data.message}); clear(); setForm({name:"",email:"",address:""}); }
      else setCheckoutMsg({ok:false,msg:data.error||"Checkout failed"});
    }catch(e){ setCheckoutMsg({ok:false,msg:"Network error"}); }
    setLoading(false);
  };

  return (
    <section id="cart" className="container mb-4">
      <h3>Shopping Cart</h3>
      {cart.length===0 ? <p>Your cart is empty.</p> : (
        <div className="card p-3">
          <table className="table">
            <thead><tr><th>Product</th><th>Qty</th><th>Price</th><th></th></tr></thead>
            <tbody>
              {cart.map(i=> (
                <tr key={i.id}>
                  <td>{i.title}</td>
                  <td style={{width:140}}><input className="form-control" type="number" value={i.qty} onChange={e=>updateQty(i.id, parseInt(e.target.value||1))} /></td>
                  <td>₹{(i.price*i.qty).toFixed(2)}</td>
                  <td><button className="btn btn-sm btn-danger" onClick={()=>remove(i.id)}>Remove</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="d-flex justify-content-between align-items-center">
            <strong>Total: ₹{total.toFixed(2)}</strong>
            <button className="btn btn-outline-secondary" onClick={clear}>Clear</button>
          </div>
          <hr/>
          <h5>Checkout (Simulation)</h5>
          <div className="row g-2">
            <div className="col-md-4"><input className="form-control" placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} /></div>
            <div className="col-md-4"><input className="form-control" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} /></div>
            <div className="col-md-4"><input className="form-control" placeholder="Address" value={form.address} onChange={e=>setForm({...form, address:e.target.value})} /></div>
          </div>
          <div className="mt-2 d-flex gap-2">
            <button className="btn btn-success" onClick={checkout} disabled={loading}>{loading ? "Processing..." : "Place Order"}</button>
            {checkoutMsg && <span className={"badge " + (checkoutMsg.ok ? "bg-success" : "bg-danger")}>{checkoutMsg.msg}</span>}
          </div>
        </div>
      )}
    </section>
  );
}

/* --------- App --------- */
function App(){
  return (
    <CartProvider>
      <Header/>
      <ProductList/>
      <Cart/>
      <footer className="container mt-4"><small>Demo only — no payments. Data stored on server when checkout.</small></footer>
    </CartProvider>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
